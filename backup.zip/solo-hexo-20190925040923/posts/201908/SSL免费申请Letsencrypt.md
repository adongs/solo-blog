title: SSL 免费申请-Letsencrypt
date: '2019-08-12 18:37:23'
updated: '2019-08-12 19:01:25'
tags: [ssl]
permalink: /articles/2019/08/12/1565606243689.html
---
![](https://img.hacpai.com/bing/20190119.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言
> Let's Encrypt是非营利性[互联网安全研究组（ISRG）](https://www.abetterinternet.org/)为您提供的免费，自动化和开放的证书颁发机构

## 安装certbot软件

```sh
# 添加源
add-apt-repository ppa:certbot/certbot
# 更新列表
apt-get update
# 安装插件
apt-get install python-certbot-nginx
```

## 配置nginx
```
# 在nginx配置文件中加入如下(/etc/nginx/sites-available/default)
server {
   listen 80;
   listent [::]:80;
   # server_name 是你需要申请的域名,多个以空格隔开
   server_name www.xxx.com xxx.com;
}

# 保存测试一下,确定修改对了
nginx -t
# 修改正确会有如下提示
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful

# 重启nginx
 service nginx reload
```
## 申请域名
```
# 申请命令(-d你需要申请的域名,多个域名在后后面追加 -d www.xxx.com)
certbot --nginx -d www.xxx.com -d xxx.com
# 提示如下
```
![sslletsencrypt.png](https://img.hacpai.com/file/2019/08/sslletsencrypt-70723e18.png)


## 续签ssl

```
# 续签(续签后ssl只会放在原来的目录下)
sudo certbot renew --dry-run
```

## 定时续签
> 由于申请的只有3个月的有效期,需要每3个月更新一次

```
# 添加定时任务
crontab -e

# 添加如下内容(每月1号执行一次)
0 0 1 * * certbot rennew --dry-run

# 查看定时任务列表 
crontab -l
```


## 最新申请地址
1. [certbot](https://certbot.eff.org)
2. [letsencrypt](https://letsencrypt.org)

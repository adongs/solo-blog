title: spring-boot-starter-actuator 开放端点
date: '2019-07-23 15:38:26'
updated: '2019-07-23 18:35:19'
tags: [springcloud, springboot]
permalink: /articles/2019/07/23/1563867506462.html
---
![](https://img.hacpai.com/bing/20181114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 端点

> Spring boot 2.0+

| ID|描述| 默认启用 |JMX曝光|Web曝光
| --- | --- | --- |---|---|
| auditevents |  显示当前应用程序的审计事件信息 |  Yes |Yes|No
| beans |  显示一个应用中`所有Spring Beans`的完整列表 |  Yes |Yes|No
| conditions |  显示`配置类和自动配置类`(configuration and auto-configuration classes)的状态及它们被应用或未被应用的原因 |  Yes |Yes|No
| configprops |  显示一个所有`@ConfigurationProperties`的集合列表 |  Yes |Yes|No
| env |  显示来自Spring的 `ConfigurableEnvironment`的属性 |  Yes |Yes|No
| flyway |  显示数据库迁移路径，如果有的话 |  Yes |Yes|No
| health |  显示应用的`健康信息`（当使用一个未认证连接访问时显示一个简单的’status’，使用认证连接访问则显示全部信息详情） |  Yes |Yes|Yes
| info |  显示任意的`应用信息` |  Yes |Yes|Yes
| liquibase |  展示任何Liquibase数据库迁移路径，如果有的话 |  Yes |Yes|No
| metrics |  展示当前应用的`metrics`信息 |  Yes |Yes|No
| mappings |  显示一个所有`@RequestMapping`路径的集合列表 |  Yes |Yes|No
| scheduledtasks |  显示应用程序中的`计划任务` |  Yes |Yes|No
| sessions |  允许从Spring会话支持的会话存储中检索和删除(retrieval and deletion)用户会话。使用Spring Session对反应性Web应用程序的支持时不可用。 |  Yes |Yes|No
| shutdown |  允许应用以优雅的方式关闭（默认情况下不启用） |  No |Yes|No
| threaddump |  执行一个线程dump |  Yes |Yes|No
| heapdump |  返回一个GZip压缩的`hprof`堆dump文件 |  Yes |N/A|No
| jolokia |  通过HTTP暴露`JMX beans`（当Jolokia在类路径上时，WebFlux不可用） |  Yes |Yes|No
| logfile |  返回`日志文件内容`（如果设置了logging.file或logging.path属性的话），支持使用HTTP **Range**头接收日志文件内容的部分信息 |  Yes |Yes|No
| prometheus |  以可以被Prometheus服务器抓取的格式显示`metrics`信息 |  Yes |N/A|No
|bus-refresh|Spring Cloud Bus 更新配置信息|No|No|No
|bus-env| Spring Cloud Bus 修改配置文件value|No|No|No

> 启用端点

- 默认情况下,除**shutdown**以外的所有端点均已启用。要配置`单个端点的启用`，请使用`management.endpoint.<id>.enabled`属性。以下示例启用**shutdown**端点
```
management:
        endpoint:
	   shutdown:
	       enabled: true
```

- 通过`management.endpoints.enabled-by-default`来修改全局端口默认配置,以下示例启用info端点并禁用所有其他端点：
```
management:
        endpoint:
	   enabled-by-default: true
	   info:
	     enabled: true
```
- 如果您只想更改端点公开(对外暴露)的技术，请改为使用`include`(开放)和`exclude`(关闭)属性

|Property|Default|
|---|---|
| management.endpoints.jmx.exposure.exclude |  * |
| management.endpoints.jmx.exposure.include |  * |
| management.endpoints.web.exposure.exclude |  * |
| management.endpoints.web.exposure.include |  info, health |









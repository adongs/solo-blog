title: mac 搭建golang环境
date: '2019-08-13 12:39:25'
updated: '2019-08-13 12:51:04'
tags: [go, mac]
permalink: /articles/2019/08/13/1565671165076.html
---
![](https://img.hacpai.com/bing/20181028.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 下载golang安装包(pkg包方式)
1. [golang安装包下载](https://golang.google.cn/dl/)

## 安装golang(pkg包方式)
1.点击安装
![golanginstall0.png](https://img.hacpai.com/file/2019/08/golanginstall0-9737f4e1.png)
2.点击继续
![golanginstall1.png](https://img.hacpai.com/file/2019/08/golanginstall1-d613cc14.png)
3.安装完成移到废纸篓
![golanginstall2.png](https://img.hacpai.com/file/2019/08/golanginstall2-c278786b.png)
4.配置环境变量
```
#编辑环境变量
vim ~/.bash_profile
#添加如下内容
# GOROOT
export GOROOT=/usr/local/go
# GOPATH 这个目录可以自定
export GOPATH=$HOME/Documents/Go
# GOPATH目录和GOROOT下面的bin目录加入系统环境变量中
export PATH=$PATH:$GOPATH/bin:$GOROOT/bin
```
5.执行生效
```
#生效
source ~/.bash_profile

# 如果你的mac安装了zsh,需要编辑~/.zshrc文件,在末尾加入如下内容
source ~/.bash_profile
```
6.检查安装是否成功
```
# 输出go版本
go version
#输出像如下内容表示安装成功
go version go1.12.7 darwin/amd64
```
## 卸载golang(pkg包方式)
1.删除golang安装目录
```
sudo rm -rf /usr/local/go
```
2.删除如下文件夹
```
sudo rm -rf /etc/paths.d/go
```
3.删除环境变量
```
#编辑环境变量配置,删除所有golang相关的变量
vim ~/.bash_profile
```
4.检查golang残余文件
```
# 检查golang包
pkgutil --pkgs | grep -i go
# 检查go命令是否存在
which go
```


## 安装golang(brew方式安装)

1.安装golang
```
#搜索golang
brew search golang
#安装golang
brew install golang
#如果卡在如下界面,按control + c 即可跳过
```
![golangbrewinstallloading.png](https://img.hacpai.com/file/2019/08/golangbrewinstallloading-d344e9c5.png)
```
# 查看环境变量
go env
#如果提示如下(如果正常显示不用管,已经安装完成了)
go: cannot find GOROOT directory: /usr/local/go
#编辑环境文件
vim ~/.bash_profile
#内容添加如下

# GOROOT
export GOROOT=/usr/local/Cellar/go/1.12.6/libexec
# GOPATH 这个目录可以自定
export GOPATH=$HOME/Documents/Go
# GOPATH目录和GOROOT下面的bin目录加入系统环境变量中
export PATH=$PATH:$GOPATH/bin

#保存文件,并执行生效
source ~/.bash_profile
#再次执行 go env,提示如下表示安装成功了
```
![golanggoenv.png](https://img.hacpai.com/file/2019/08/golanggoenv-54f20ac4.png)

## golang卸载(brew方式安装)

1.卸载golang
```
brew remove go
```
2.删除环境变量
```
# 编辑环境变量,删除所有go相关的环境变量
vim ~/.bash_profile
```

## 相关资料

1.[golang官网](https://golang.google.cn/)



title: Spring Batch (一) -简介篇
date: '2019-08-15 14:07:47'
updated: '2019-08-15 14:54:34'
tags: [SpringBatch, Spring]
permalink: /articles/2019/08/15/1565849267073.html
---
![](https://img.hacpai.com/bing/20190530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Spring Batch 简介
> Spring Batch提供了可重复使用的功能，这些功能对于处理大量记录至关重要，包括记录/跟踪，事务管理，作业处理统计，作业重启，跳过和资源管理。它还提供更高级的技术服务和功能，通过优化和分区技术实现极高容量和高性能的批处理作业。简单和复杂的大批量批处理作业可以高度可扩展的方式利用框架来处理大量信息。

## 什么是批处理
> 现代互联网企业、金融业、电信业甚至传统行业通过OLTP（联机事务处理）的业务系统积累了海量企业数据，需要企业应用能够在关键任务中进行批量处理来操作业务逻辑。通常情况下，此类业务并不需要人工参与就能够自动高效地进行复杂数据处理与分析。例如，定期对大批量数据进行业务处理（如银行对账和利率调整、或者跨系统的数据同步），或者是把从内部和外部系统中获取到的数据进行处理后集成到其他系统中去，这类工作被称之为“批处理”。“批处理”工作在面对复杂的业务以及海量的数据处理时，无需人工干预，仅需定期读入批量数据，然后完成相应业务处理并进行归档操作。


## Spring Batch 优势
1. SpringBatch框架通过提供丰富的即开即用的组件和高可靠性、高扩展性的能力，使得开发批处理应用的人员专注于业务的处理，提升批处理应用的开发效率，通过SpringBatch可以快速地构建出轻量级的健壮的并行处理应用。
2. 批处理开发人员使用Spring编程模型：专注于业务逻辑，让框架负责基础架构
3. 提供通用的核心执行服务作为所有项目可以实现的接口
4. 清楚地分离基础架构，批处理执行环境和批处理应用程序之间的关注点
5. 提供一个简单的部署模型，使用Maven构建的架构JAR与应用程序完全分离

# Spring Batch 使用场景

> 一般的典型批处理程序

1. 从数据库，文件或队列中读取大量记录
2. 以某种方式处理数据
3. 以修改的形式写回数据

> Spring Batch 业务场景

1. 定期提交批处理
2. 并发批处理：并行处理作业
3. 分阶段的企业消息驱动处理
4. 大规模并行批处理
5. 失败后手动或预定重启
6. 依赖步骤的顺序处理（使用扩展的toworkflow驱动批次）
7. 部分处理：跳过记录（例如，回滚时）
8. 整批交易，适用于批量较小或现有存储过程/脚本的情况



## Spring Batch 新特性

> Spring Batch 4.2.x
1. 使用[Micrometer(使用Micrometer监控批处理作业,默认情况下,Spring Batch会收集指标（例如作业持续时间，步骤持续时间，项目读取和写入吞吐量等），并在Micrometer的全局指标注册表中将其注册在`spring.batch`前缀下。这些指标可以发送到 Micrometer支持的任何监控系统)](https://micrometer.io/)支持批量指标
2. 支持从/向[Apache Kafka](https://kafka.apache.org/)主题读取/写入数据
3. 改进文档

> Spring Batch 4.1.x
1. 新的`@SpringBatchTest`注释，用于简化测试批处理组件
2. 新的`@EnableBatchIntegration`注释，用于简化远程分块和分区配置
3. 新的`JsonItemReader`并`JsonFileItemWriter`支持JSON格式
4. 添加对使用Bean Validation API验证项目的支持
5. 添加对JSR-305注释的支持
6. `FlatFileItemWriterBuilder`API的增强功能
7. 增加了对JSON格式的支持

> Spring Batch 4.0.x

1. 升级到Java 8 
2. Spring Batch 4正在全面更新依赖关系。新的依赖版本与Spring Framework 5一致。
3. 为ItemReaders，ItemProcessors和ItemWriters提供构建器

## Spring Batch 分层架构
![springbatcharchitecture.png](https://img.hacpai.com/file/2019/08/springbatcharchitecture-6ab994a7.png)

> 这种分层架构突出了三个主要的高级组件：应用程序，核心和基础架构。该应用程序包含开发人员使用Spring Batch编写的所有批处理作业和自定义代码。Batch Core包含启动和控制批处理作业所需的核心运行时类。它包括实现 `JobLauncher`，`Job`和`Step`。Application和Core都建立在通用基础架构之上。此基础结构包含常见的读取器和编写器和服务（例如`RetryTemplate`），应用程序开发人员（读取器和编写器，如`ItemReader`和`ItemWriter`）以及核心框架本身（重试，自己的库）都使用它们。

title: Spring cloud config(配置服务)服务搭建
date: '2019-07-22 16:45:03'
updated: '2019-07-23 18:35:46'
tags: [springcloud]
permalink: /articles/2019/07/22/1563785103493.html
---
![](https://img.hacpai.com/bing/20180325.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 简介

> Spring Cloud Config为分布式系统中的外部化配置提供服务器和客户端支持。通过Config Server，您可以在所有环境中管理应用程序的外部属性。客户端和服务器上的概念与Spring Environment和PropertySource抽象，因此它们非常适合Spring应用程序，但可以与任何运行在任何语言的应用程序一起使用。随着应用程序从开发到测试转移到部署管道中，您可以管理这些环境之间的配置，并确保应用程序具有迁移时所需的所有内容。服务器存储后端的默认实现使用git，因此它可以轻松支持配置环境的标签版本，并且可以用于管理内容的各种工具。使用Spring配置很容易添加替代实现并将其插入。


## 场景
> 一个系统有50服务节点,每个节点启动一个服务,现在需要修改某一个配置,没有 Spring Cloud Config服务之前,你需要修改每一个节点的配置,有了 Spring Cloud Config 服务只需要修改一个文件即可,方便管理全局的配置文件


## 示例

> 创建父工程

1. 笔者使用idea创建
![springcloudconfig1.png](https://img.hacpai.com/file/2019/07/springcloudconfig1-77e6fe4c.png)

2. 都不选
![springcloudconfig2.png](https://img.hacpai.com/file/2019/07/springcloudconfig2-18103250.png)

3. 删除不需要的文件(.mvn目录,scr目录,mvnw,mvnw.cmd)

> 创建config-server

1. 选中父项目右键 New -> Module

2. 选择如下
![springcloudconfig3.png](https://img.hacpai.com/file/2019/07/springcloudconfig3-98ce44c7.png)

3. 添加 @EnableConfigServer 注解
![springcloudconfig4.png](https://img.hacpai.com/file/2019/07/springcloudconfig4-36e35583.png)

4. 修改 application.properties 为application.yml 内容如下
![springcloudconfig5.png](https://img.hacpai.com/file/2019/07/springcloudconfig5-a1464325.png)

5.application.yml内容
```
server:
  port: 8888
spring:
  application:
    name: config-server
  profiles:
    active: native
  cloud:
    config:
      server:
        native:
          search-locations:
```

6. 添加 client-dev.yml  client-test.yml 内容如下
![springcloudconfig6.png](https://img.hacpai.com/file/2019/07/springcloudconfig6-127d743a.png)
7.  client-dev.yml 内容
```
dome:
  name: demo-dev
server:
  port: 8081
```
8. client-test.yml内容
```
dome:
  name: demo-test
server:
  port: 8082
```


> 创建config-client(使用config服务demo)

1. 选中父项目右键 New -> Module

2. 选择如下
![springcloudconfig7.png](https://img.hacpai.com/file/2019/07/springcloudconfig7-a20f14db.png)

3. 创建一个Controller 内容如下
![springcloudconfig8.png](https://img.hacpai.com/file/2019/07/springcloudconfig8-1e36d1dd.png)

4. 修改 application.properties 为bootstrap.yml 内容如下([bootstrap和application区别](https://adongs.com/articles/2019/07/22/1563789226071.html))
![springcloudconfig9.png](https://img.hacpai.com/file/2019/07/springcloudconfig9-9f092342.png)

5. bootstrap.yml 内容
```
spring:
   cloud:
    config:
      profile: dev
      uri: http://localhost:8888
   application:
     name: client

```


> 整个项目结果如下

![springcloudconfig10.png](https://img.hacpai.com/file/2019/07/springcloudconfig10-d3bfff53.png)


> 启动项目测试
1. 启动server和client
![springcloudconfig11.png](https://img.hacpai.com/file/2019/07/springcloudconfig11-b0f244bf.png)
2. 打开浏览器输入http://localhost:8081/test
![springcloudconfig12.png](https://img.hacpai.com/file/2019/07/springcloudconfig12-5aa6cc39.png)

> Demo地址
1. [demo](https://github.com/adongs/spring-cloud-config-demo.git)


## 相关配置说明

-  config-server
```
server:
  port: 8888 //启动服务端口
spring:
  application:
    name: config-server //服务名称
  profiles:
    active: native //本地模式
  cloud:
    config:
      server:
        native:
          search-locations:    //读取路径
```

-  config-clien
```
spring:
   cloud:
    config:
      profile: dev //环境
      uri: http://localhost:8888 //config地址,逗号分隔填写多个
   application:
     name: client //应用名称

```


- `{application}`，映射到`spring.application.name`客户端
- `{profile}`，映射到`spring.profiles.active`客户端（以逗号分隔的列表）
- `{label}`，这是标记“版本化”配置文件集的服务器端功能

























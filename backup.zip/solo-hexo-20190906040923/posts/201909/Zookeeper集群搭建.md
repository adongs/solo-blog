title: Zookeeper集群搭建
date: '2019-09-05 16:01:41'
updated: '2019-09-05 16:39:42'
tags: [zookeeper]
permalink: /articles/2019/09/05/1567670501099.html
---
![](https://img.hacpai.com/bing/20190525.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 简介
> Zookeepe分布式服务框架，是Apache Hadoop 的一个子项目，它主要是用来解决分布式应用中经常遇到的一些数据管理问题，如：统一命名服务、状态同步服务、集群管理、分布式应用配置项的管理等

## 结构图
### zookeeper维护一个类似文件系统的数据结构
![zookeeperstructure.png](https://img.hacpai.com/file/2019/09/zookeeperstructure-1a8143e7.png)

### 节点类型

| 类型 | 名称|说明 | 
| --- | --- | ---|
PERSISTENT|持久化目录节点|客户端与zookeeper断开连接后，该节点依旧存在
PERSISTENT_SEQUENTIAL|持久化顺序编号目录节点|客户端与zookeeper断开连接后，该节点依旧存在，只是Zookeeper给该节点名称进行顺序编号
EPHEMERAL|临时目录节点|客户端与zookeeper断开连接后，该节点被删除
EPHEMERAL_SEQUENTIAL|临时顺序编号目录节点|客户端与zookeeper断开连接后，该节点被删除，只是Zookeeper给该节点名称进行顺序编号

### 通知机制
客户端注册监听它关心的目录节点，当目录节点发生变化（数据改变、被删除、子目录节点增加删除）时，zookeeper会通知客户端

### 分布式配置管理
> 如果我们应用分布在多台服务器上,当我们修改程序配置文件,需要对多台进行修改,非常麻烦,如果有上千台服务器,那更是不可能的任务,现在节点上创建一个节点,并把这些配置文件保存在zookeeper的某个子节点中,所有需要这个配置文件的客户端对这个节点进行监听,一旦配置信息发生变化,每个客户端都能收到zookeeper的通知,然后客户端拉去最新的配置文件
![zookeeperclient.png](https://img.hacpai.com/file/2019/09/zookeeperclient-4ffbfc9d.png)

## 伪集群搭建

### 1.docker 安装 zookeeper
```
sudo docker pull zookeeper:3.4.9
```

### 2.创建一个zookeeper配置文件
```
sudo mkdir /var/zookeeper1
```

### 3.下载zookeeper安装包
```
http://mirror.bit.edu.cn/apache/zookeeper/zookeeper-3.4.10/zookeeper-3.4.10.tar.gz
```

### 4.解压,目录结构如下
![zookeeper1.png](https://img.hacpai.com/file/2019/09/zookeeper1-05c07491.png)


### 5.拷贝conf配置目录
```
cp -r 解压目录/zookeeper-3.4.10/conf  /var/zookeeper1
```
### 6.创建配置
```sh
# 进入配置目录
cd /var/zookeeper1/conf
# 拷贝配置文件
cp zoo_sample.cfg  zoo.cfg
# 编辑zoo.cfg修改如下
tickTime=2000
initLimit=10
syncLimit=5
dataDir=/data
dataLogDir=/datalog
# 3份每份分别为 2181,2182,2183
clientPort=2181
# 下面的1,2,3 对应着myid中的值    (ip:原子广播端口:选举端口)
# 如果你的docker 没有使用host模式  server.2和server.3 的ip为真实机ip 只有和myid相同的那个ip为0.0.0.0或者120.0.0.1
server.1=127.0.0.1:2887:3887 
server.2=127.0.0.1:2888:3888
server.3=127.0.0.1:2889:3889

# 创建data目录
mkdir /var/zookeeper1/data
```

### 7.配置文件复制
```sh
cp -r /var/zookeeper1 /var/zookeeper2
cp -r /var/zookeeper1 /var/zookeeper3
# 分别对应写入3分文件
echo "1" > /var/zookeeper1/data/myid
echo "2" > /var/zookeeper2/data/myid
echo "3" > /var/zookeeper3/data/myid
```

### 8.启动集群(分别指定了配置文件的位置,data目录的位置,以及日志目录的位置),需要启动3个节点
```sh
#节点1
sudo docker run -tid  \
--name=zookeeper1  \
--restart=always  \
--net=host \
-v /var/zookeeper1/cong:/conf  \
-v /var/zookeeper1/data:/data  \
-v /var/zookeeper1/datalog:/datalog \
zookeeper:3.4.9

#节点2
sudo docker run -tid  \
--name=zookeeper2  \
--restart=always  \
--net=host \
-v /var/zookeeper2/cong:/conf  \
-v /var/zookeeper2/data:/data  \
-v /var/zookeeper2/datalog:/datalog \
zookeeper:3.4.9

#节点3
sudo docker run -tid  \
--name=zookeeper3  \
--restart=always  \
--net=host \
-v /var/zookeeper3/cong:/conf  \
-v /var/zookeeper3/data:/data  \
-v /var/zookeeper3/datalog:/datalog \
zookeeper:3.4.9

```


## 测试

> 分别进入3个zookeeper查看角色
```
# 查看启动的zookeeper
docker ps

# 进入第一个
docker exec -it [CONTAINER ID] /bin/sh
# 执行查看状态
./bin/zkServer.sh status
#显示如下内容
ZooKeeper JMX enabled by default
Using config: /conf/zoo.cfg
Mode: follower

# 进入第二个显示
ZooKeeper JMX enabled by default
Using config: /conf/zoo.cfg
Mode: leader

#进入第三个显示
ZooKeeper JMX enabled by default
Using config: /conf/zoo.cfg
Mode: follower

```



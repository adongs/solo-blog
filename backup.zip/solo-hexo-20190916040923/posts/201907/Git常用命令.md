title: Git常用命令
date: '2019-07-31 17:11:21'
updated: '2019-08-12 16:22:47'
tags: [git]
permalink: /articles/2019/07/31/1564564281860.html
---
![](https://img.hacpai.com/bing/20190113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 新项目加入git并且推送到github
```
#进入项目,初始化git
git init
git commit -m "初始化项目"
#你也可以使用如下命令,git add 和 git commit 合成一个
git commit -m  -a  "初始化项目"
#如果提交,你需要注释换行,敲一个",然后直接回车就换行了,完成后敲剩下的" 回车即可
git commit -m  -a  "初始化项目 
> 换行测试 
> "
#添加远程地址
git remote add origin 你的github或者你的gitlab仓库地址
#提交到远程
git push -u origin master
#重新设置远程地址
git remote set-url origin 你的github或者你的gitlab仓库地址
#查看所有远程仓库
git remote
#查看指定远程仓库地址
git remote 远程仓库名称(例如:origin)
#删除远程仓库
git remote rm 远程仓库名称(例如:origin)
#克隆项目 如果给 git clone 命令传递 --recursive 选项，它就会自动初始化并更新仓库中的每一个子模块
git clone --recursive https://github.com/chaconinc/MainProject
```
## Tag

```
#查看Tag列表 
git tag 
#如果你发现gitlib或者github上的Tag在这个列表上没有,是没有同步,执行下列指令 
git pull 
#可以通过如下指令进行模糊查询 
git tag -l  "v1.4.2.*" 
#查看标签的详细信息 git show 标签名称 
#打标签 
#创建轻量级标签 
git tag 标签名称 -m  '标签说明' 
#创建一个含附注类型的标签 
git tag -a 标签名称 -m  '标签说明' 
#如果你有自己的私钥，还可以用 GPG 来签署标签 
git tag -s 标签名称 -m  '标签说明' 
#对早先提交的分支打标签 
#显示提交历史 
git log --pretty=oneline 
#会显示如下格式信息 
15027957951b64cf874c3557a0f3547bd83b3ff6 Merge branch 'experiment' a6b4c97498bd301d84096da251c98a07c7723e65 beginning write support 0d52aaab4479697da7686c15f77a3d64d9165190 one more thing 
#选定一个提交记录打标签 
git tag -a v1.2 0d52aa 
#推送指定
tag git push origin tag名称 
#推送所有的
tag git push origin --tags 
#删除本地Tag 
git tag -d 标签名称 
#删除远程的Tag 
git push origin :refs/tags/标签名称
```
## 撤销操作

```
#撤销merge 
git merge --abort
#撤回merger(已经合并,并且没有冲突)
git log 
#找到merger的commitID
git reset --hard commitID
#撤销pull 操作(比如pull后冲突的,你想撤销pull)
git reset --merge
#如果你想删除未监控的文件或者文件夹
# 参数: f(删除文件), d(删除目录), n(列出删除的文件)
git clean -参数  
#如果你想撤回 git add 的操作
#撤回全部
git reset HEAD
#撤回指定文件
git reset HEAD XXX/XXX/XXX.java
#如果你想撤回 git commit 的操作
#查看提交日志
git log
#撤回提交(回退到上一个 提交的节点 代码还是原来你修改的)
git reset commit_id
#撤回提交(回退到上一个commit节点， 代码也发生了改变，变成上一次的)
git reset –hard commit_id
```
## 暂存区
```
#保存当前的修改到暂存区
git stash
#保存当前修改到暂存区,加上描述
git stash save '描述信息'
#显示保存列表
git stash list
#恢复最近保存的记录并把恢复的记录从保存列表中删除
git stash pop
#恢复保存列表里面指定的保存记录，并把恢复的记录从保存列表中删除
git stash pop stash@{序号} 
#恢复最近保存的记录但不会删除保存列表里面对应的记录
git stash apply
#删除暂存区最近保存的记录
git stash drop
#删除暂存区指定的保存的记录
git stash drop stash@{序号} 
#删除保存区里面所有的记录
git stash clear
```

## 保存用户名和密码

```
#查看当前配置
git config --list
# 环境说明
# --system(对所有用户都配置,配置写入:/etc/gitconfig文件) 
# --global(对系统下用户都配置,配置写入:~/.gitconfig文件) 
# 什么都不写(只对当前项目,配置写入:当前项目/.git/config文件)
# --system > --global > 什么都不写  配置会由大到小覆盖,最大的始终覆盖小的
#配置用户名
git config --global user.name "John Doe"
#配置邮箱地址
git config --global user.email johndoe@example.com
#查看辅助程序配置
git config --list | grep credential
# 参数1:global(全局),local(当前项目)  参数2: cache,store,osxkeychain
#cache:模式会将凭证存放在内存中一段时间。密码永远不会被存储在磁盘中，并且在15分钟后从内存中清除
#store:模式会将凭证用明文的形式存放在磁盘中，并且永不过期,密码是明文存在home目录下的
#osxkeychain: Mac将凭证缓存到你系统用户的钥匙串中,这种方式将凭证存放在磁盘中，并且永不过期
git config --{参数1} credential.helper {参数2}
#“store” 模式可以接受一个 --file <path>参数,可以自定义存放密码的文件路径（默认是`~/.git-credentials`）
git config --global credential.helper store --file ~/.my-credentials
#例子:设置一个明文文件存储的，也就是store类型的全局存储
git config --global credential.helper store
#删除保存后的密码
git config --global --unset credential.helper -f
git config --local --unset credential.helper -f
rm -rf $HOME/git-credentials
rm ~/.git-credentials 
#验证删除成功,看不到结果即删除成功
git credential-store get
```

## 强制线上覆盖本地文件
```sh
#git pull --force <远程主机名> <远程分支名>:<本地分支名> 
#例如 git pull --force origin master:master 
git pull --force
```




## 将一个分支的commit转移到另外一个分支上
```
git checkout <分支名称1> 
#找到要转的commit ID 
git log 
git checkout <分支名称2> 
#即可将分支1的commit转到分支2上 
git cherry-pick <commit ID>
```

## 删除历史的某一个commit
```
# 查看log日志
git log
```
> 列出如下操作
```
commit 0e7d900ae62b29420232dcca30e06b1d2e5f65a9 
Author:test <xxxxx@qq.com>
Date:   Mon Aug 12 10:17:09 2019 +0800

   D

commit 6c947f75e49e016348599447aeab2f59b4a30f74
Author:test <xxxxx@qq.com>
Date:   Fri Aug 9 19:30:53 2019 +0800

    C

commit 5c55d37dfee32f42bb040982ef58a5f1b3a57813
Author:test <xxxxx@qq.com>
Date:   Fri Aug 9 16:18:45 2019 +0800

    B

commit 0d13aef1cbef5c0a73aa8b82cd24a5476fdec984
Author:test <xxxxx@qq.com>
Date:   Fri Aug 9 15:13:56 2019 +0800

    A

```

```sh
# 例如我们需要删除"C"这次commit
# 我们需要选择C的下一面一个commit-id(即B的commit)
git rebase -i commit-id
```
> 提示如下编辑(本质就是用vim编辑一个文件)
```
pick 5c55d37d B
pick 6c947f75  C
pick 0e7d900a D

# Rebase 0d13aef1..0e7d900a onto 0d13aef1 (3 commands)
#
# Commands:
# p, pick = use commit
# r, reword = use commit, but edit the commit message
# e, edit = use commit, but stop for amending
# s, squash = use commit, but meld into previous commit
# f, fixup = like "squash", but discard this commit's log message
# x, exec = run command (the rest of the line) using shell
# d, drop = remove commit
#
# These lines can be re-ordered; they are executed from top to bottom.
#
# If you remove a line here THAT COMMIT WILL BE LOST.
#
# However, if you remove everything, the rebase will be aborted.
#
# Note that empty commits are commented out

```
```
# 将C的前面的pick修改为drop并保存,提示如下
Successfully rebased and updated refs/heads/test
# 推送到远程分支
git push origin HEAD –force
```















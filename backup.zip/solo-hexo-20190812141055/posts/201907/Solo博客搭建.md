title: Solo博客搭建
date: '2019-07-19 14:44:32'
updated: '2019-08-12 13:51:43'
tags: [Solo]
permalink: /articles/2019/07/19/1563518672127.html
---
![](https://img.hacpai.com/bing/20181205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##  服务器

1. 申请云服务器(这里笔者选择腾讯云,使用学生套餐便宜)
![腾讯云服务器.png](https://img.hacpai.com/file/2019/07/腾讯云服务器-260efba2.png)

2. 选择系统(这里笔者建议使用自己熟悉的系统,如果你不熟悉linux可以跟随笔者选择的系统)
![云服务器系统.png](https://img.hacpai.com/file/2019/07/云服务器系统-26f0d84d.png)

3. 创建云服务器登录方式选择密码方式(方便上传文件)

4. 配置创建好的云服务器安全组,配置如下
![入站安全组.png](https://img.hacpai.com/file/2019/07/入站安全组-0dd5da91.png)
![出站安全组.png](https://img.hacpai.com/file/2019/07/出站安全组-96a7ce53.png)



## 申请域名

 1. 查询域名
![域名查询.png](https://img.hacpai.com/file/2019/07/域名查询-1c407efe.png)
 2. 购买域名(购买完域名,需要备案才能解析和访问)
3. 备案域名(备案周期在30天左右)

## 安装服务

 1. 登录服务器(mac直接打开终端,Windows系统需要安装软件Secure CRT)
```
ssh -p 22 系统用户名@公网ip
# 例如
ssh -p 22 ubuntu@10.22.33.49
``` 

 2. 安装docker
```
sudo apt-get install docker.io
```

 3. 安装nginx
```
sudo apt-get install  nginx
```

4. 安装mycli(命令行操作mysql的智能提示工具)
```
sudo apt-get install mycli
```

5. 安装vim
```
sudo apt-get install vim
```


6. 使用docker安装solo和mysql
```
# 下载mysql 镜像
sudo docker pull mysql
# 启动镜像  MYSQL_ROOT_PASSWORD=mysql的root密码
docker run -d --name mysql-5.7 --network=host -v /var/lib/mysql:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root  mysql:5.7 --character-set-server=utf8mb4 --collation-server=utf8mb4_general_ci
# 登录mysql
mycli
# 创建数据库
CREATE DATABASE solo DEFAULT CHARACTER SET utf8mb4  DEFAULT COLLATE utf8mb4_general_ci
# 退出mycli工具
quit


# 下载solo博客镜像
sudo docker pull b3log/solo

# 启动solo镜像 
# JDBC_PASSWORD(mysql的密码)  
# listen_port(启动端口)  
# server_scheme(访问协议) 
# server_host(请求的地址) 
# server_port(请求的端口)
 docker run --detach --name solo --network=host \
        --env RUNTIME_DB="MYSQL" \
        --env JDBC_USERNAME="root" \
        --env JDBC_PASSWORD="root" \
        --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
        --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
        b3log/solo --listen_port=8080 --server_scheme=https --server_host=adongs.com --server_port=80
# 查看启动结果
sudo docker ps
# 结果如下就表示启动成功(STATUS 都为UP表示启动成功)
```
![docker启动容器列表.png](https://img.hacpai.com/file/2019/07/docker启动容器列表-5543de9b.png)


## 配置域名和代理

1. 申请SSL(笔者在腾讯云申请的免费SSL)

2. 下载SSL到本地,并解压

3. 上传SSL到云服务器
```
scp -r SSL文件目录 系统用户名@公网i:/home/系统用户名
```

4. 配置nginx
```
#登录云服务器,执行如下
sudo vim /etc/nginx/sites-enabled/default
#将文本里面的内容全删除,拷贝如下文本内容
#修改server_name为自己的域名
#修改ssl_certificate和ssl_certificate_key的文件路径
#修改proxy_pass为自己的域名和solo启动端口
server {
        listen    443 ssl;
        server_name www.xxx.com,xxx.com;
        ssl_certificate  /etc/nginx/ssl/xxx.crt;
        ssl_certificate_key /etc/nginx/ssl/xxx.key;

        location / {
                proxy_pass http://www.adongs.com:8080;
        }
}

server {
        listen     80;
        listen     [::]:80;
        server_name www.xxx.com,xxx.com;
        return 301 https://$host$request_uri;
}

# 保存并退出后重启nginx
nginx -s reload

```


## 调试

1.打开自己的域名如下
![博客调试.png](https://img.hacpai.com/file/2019/07/博客调试-d6234d24.png)

## 相关资料
1. [solo地址](https://github.com/b3log/solo)
2. [mysql镜像说明](https://hub.docker.com/_/mysql/)
2. [腾讯云学生购买](https://cloud.tencent.com/act/campus/)



## 感谢

1.  B3log 开源社区

## 问题

1.安装有什么问题请留言

title: Spring Cloud Config 和 Spring Cloud Bus 实现动态修改配置
date: '2019-07-23 16:21:20'
updated: '2019-07-23 18:35:07'
tags: [springcloudbus]
permalink: /articles/2019/07/23/1563870080765.html
---
![](https://img.hacpai.com/bing/20181002.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 简介
> 事件、消息总线，用于在集群（例如，配置变化事件）中传播状态变化，可与Spring Cloud Config联合实现热部署。

## 场景
> 一个系统有50服务节点,每个节点启动一个服务,现在需要修改某一个配置,没有 Spring Cloud Config服务之前,你需要修改每一个节点的配置,有了 Spring Cloud Config 服务只需要修改一个文件即可同步到其他的节点服务

## 示例

> 在[# Spring cloud config(配置服务)服务搭建](https://adongs.com/articles/2019/07/22/1563785103493.html#b3_solo_h2_3)的基础上继续修改


> docker 安装 rabbitMQ

1.docker 安装 rabbitMQ
```
# 下载rabbitmq镜像
docker pull rabbitmq

# 启动镜像
docker run -d --hostname my-rabbit --name some-rabbit -p 15672:15672 -p 5672:5672 -p 5671:5671 rabbitmq:3-management

```
2. 打开http://localhost:15672 进入管理界面(默认用户名guest 密码guest)
![springcloudconfigrabbitmq.png](https://img.hacpai.com/file/2019/07/springcloudconfigrabbitmq-97127c53.png)

> 配置文件存放github

1. 创建github仓库
![springcloudconfigbusgithub.png](https://img.hacpai.com/file/2019/07/springcloudconfigbusgithub-ff44606c.png)

2. 在创建的仓库中添加两个文件
![springcloudconfigbusgithub2.png](https://img.hacpai.com/file/2019/07/springcloudconfigbusgithub2-1ba4b35f.png)

3. 在文件client-pre.yml中添加如下内容
```
dome:
  name: demo-pre-1
server:
  port: 8081
```

4, 在文件client-pro.yml添加如下内容
```
dome:
  name: demo-pro
server:
  port: 8081
```


> 修改config-server(配置服务)

1. 在spring-cloud-config-dome>config-server>pom.xml 添加如下内容
```
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-bus-amqp</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
```
2. 修改spring-cloud-config-dome>config-server>application.yml内容如下

```
server:
  port: 8888
spring:
  application:
    name: config-server
  cloud:
    config:
      server:
          git:
            uri: https://github.com/adongs/spring-cloud-config.git  //你的github地址
            username: *****  //github用户名
            password: *****  //github密码
    bus:
      trace:
        enabled: true
      enabled: true
  rabbitmq:
    host: localhost  //rabbitmq的host
    username: guest  //rabbitmq的用户名
    password: guest  //rabbitmq的密码
    port: 5672   //rabbitmq端口
management:
  endpoints:
    web:
      exposure:
        include: bus-env,bus-refresh //暴露端点
```
3.相关知识  [spring-boot-starter-actuator 开放端点](https://adongs.com/articles/2019/07/23/1563867506462.html)


> 修改config-client(配置服务)

1. 在spring-cloud-config-dome>config-client>pom.xml 添加如下内容
```
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-bus-amqp</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
```

2. 修改spring-cloud-config-dome>config-server>bootstrap.yml内容如下
```
spring:
   cloud:
    config:
      profile: pre //环境
      uri: http://localhost:8888 //config-server 请求的url
   application:
     name: client  //应用名称
   rabbitmq:
       host: localhost   //rabbitmq的host
       username: guest  //rabbitmq的用户名
       password: guest  //rabbitmq的密码
       port: 5672  //rabbitmq端口
management:
  endpoints:
    web:
      exposure:
        include: bus-env,bus-refresh  //暴露端点
```

3. 在TestController中添加@RefreshScope
```
@RestController
@RefreshScope 
public class TestController {


    @Value("${dome.name}")
    private String name;


    @GetMapping("test")
    public String test(){
        return name;
    }
}
```



## 测试

1. 启动项目
![springcloudconfigbusstart.png](https://img.hacpai.com/file/2019/07/springcloudconfigbusstart-c74a8cd6.png)

2. 打开 http://localhost:8081/test  
![springcloudconfigbuschrome.png](https://img.hacpai.com/file/2019/07/springcloudconfigbuschrome-099540ca.png)

3. 修改github上的client-pre.yml
![springcloudconfigbusgithub3.png](https://img.hacpai.com/file/2019/07/springcloudconfigbusgithub3-7812f053.png)

4. 用postman请求 http://localhost:8888/actuator/bus-refresh POST 方式
![springcloudconfigbuspostman.png](https://img.hacpai.com/file/2019/07/springcloudconfigbuspostman-56747024.png)

5. 查看config-client(客户端)日志
![springcloudconfigbusidealog.png](https://img.hacpai.com/file/2019/07/springcloudconfigbusidealog-0122b9dd.png)
```
2019-07-23 18:14:04.325  INFO 18704 --- [YeRlKFPYbG25w-1] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.autoconfigure.ConfigurationPropertiesRebinderAutoConfiguration' of type [org.springframework.cloud.autoconfigure.ConfigurationPropertiesRebinderAutoConfiguration$$EnhancerBySpringCGLIB$$d19b210] is not eligible for getting processed by all BeanPostProcessors (for example: not eligible for auto-proxying)
2019-07-23 18:14:04.378  INFO 18704 --- [YeRlKFPYbG25w-1] c.c.c.ConfigServicePropertySourceLocator : Fetching config from server at : http://localhost:8888
2019-07-23 18:14:07.438  INFO 18704 --- [YeRlKFPYbG25w-1] c.c.c.ConfigServicePropertySourceLocator : Located environment: name=client, profiles=[pre], label=null, version=07e574c2d771aa8c4610e2907b1433f0ab30a2a4, state=null
2019-07-23 18:14:07.438  INFO 18704 --- [YeRlKFPYbG25w-1] b.c.PropertySourceBootstrapConfiguration : Located property source: CompositePropertySource {name='configService', propertySources=[MapPropertySource {name='configClient'}, MapPropertySource {name='https://github.com/adongs/spring-cloud-config.git/client-pre.yml'}]}
2019-07-23 18:14:07.439  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.boot.SpringApplication               : No active profile set, falling back to default profiles: default
2019-07-23 18:14:07.447  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.boot.SpringApplication               : Started application in 3.208 seconds (JVM running for 640.777)
2019-07-23 18:14:07.555  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.cloud.bus.event.RefreshListener      : Received remote refresh request. Keys refreshed [config.client.version, dome.name]
2019-07-23 18:14:07.568  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.a.r.c.CachingConnectionFactory       : Attempting to connect to: [localhost:5672]
2019-07-23 18:14:07.576  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.a.r.c.CachingConnectionFactory       : Created new connection: rabbitConnectionFactory.publisher#1851181e:0/SimpleConnection@46935090 [delegate=amqp://guest@127.0.0.1:5672/, localPort= 57410]
2019-07-23 18:14:07.580  INFO 18704 --- [YeRlKFPYbG25w-1] o.s.amqp.rabbit.core.RabbitAdmin         : Auto-declaring a non-durable, auto-delete, or exclusive Queue (springCloudBus.anonymous.tUNrMyFmQYeRlKFPYbG25w) durable:false, auto-delete:true, exclusive:true. It will be redeclared if the broker stops and is restarted while the connection factory is alive, but all messages will be lost.
```

6. 刷新 http://localhost:8081/test  可以看到值已经改变了
![springcloudconfigbuschorme2.png](https://img.hacpai.com/file/2019/07/springcloudconfigbuschorme2-f17df7db.png)


## Demo 地址
1. [demo地址](https://github.com/adongs/spring-cloud-config-demo/tree/config-bus)




title: Solr经纬度
date: '2019-09-04 16:25:56'
updated: '2019-09-04 16:26:15'
tags: [solr]
permalink: /articles/2019/09/04/1567585556354.html
---
![](https://img.hacpai.com/bing/20180112.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 安装Solor

> 使用docker安装Solr
```sh
docker pull solr
```

> 启动solr
```sh
docker run --name solr -d  -p 8983:8983 -t  -v  $USER_HOME/solr/data:/var/solr/data solr
```

> 查看是否启动成功,在浏览器打开http://localhost:8983/solr
![solr1.png](https://img.hacpai.com/file/2019/09/solr1-cb705171.png)

## 创建核心(相当于数据库的表)

> 创建一个核心(相当于数据库的表)
```sh
#docker exec -it --user=solr 镜像名称 bin/solr create_core -c 核心名称
docker exec  -it  --user=solr solr bin/solr create_core -c mytest
```
> 查看管理界面(会有我们创建的核心)
![solr2.png](https://img.hacpai.com/file/2019/09/solr2-4252a13c.png)

> 选择创建字段
![solr3.png](https://img.hacpai.com/file/2019/09/solr3-8fe45bac.png)


> 创建(经度和纬度),以及id字段
![solr4.png](https://img.hacpai.com/file/2019/09/solr4-d20abd0b.png)

## 造数据

> 创建一个test.xml文件,内容如下,放到$USER_HOME/solr/data文件夹中

```xml
<add>  
      <doc>  
           <field  name="gas_id">1</field>  
           <field  name="gas_ioc">23.11,39.11</field>  
      </doc>  
      <doc>  
           <field  name="gas_id">2</field>  
           <field  name="gas_ioc">50.1,48.9</field>  
      </doc>  
      <doc>  
            <field  name="gas_id">3</field>  
            <field  name="gas_ioc">23.18,39.1</field>  
      </doc>  
</add>
```
> 将xml导入到solr中

```sh
#进入solr 容器中 
docker exec  -it  --user=root solr /bin/bash 
#复制文件到指定目录 
cp /var/solr/data/test.xml example/exampledocs/ 
#执行导入 bin/post -c 核心名称 example/exampledocs/导入的数据文件名称 
bin/post -c mytest example/exampledocs/test.xml
```

> 测试
![solr5.png](https://img.hacpai.com/file/2019/09/solr5-016a4bc5.png)



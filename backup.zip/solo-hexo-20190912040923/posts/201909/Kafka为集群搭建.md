title: Kafka为集群搭建
date: '2019-09-04 17:28:07'
updated: '2019-09-06 11:18:57'
tags: [kafka]
permalink: /articles/2019/09/04/1567589287529.html
---
## 安装基础服务

> 安装docker
```
# ArchLinux安装docker  
sudo pacman -S docker 
# Ubuntu 安装docker  
sudo apt-get install docker.io 
# CentOS 安装docker  
sudo yum -y install docker
```

> docker方式安装zookeeper
- [zookeeper集群安装](https://adongs.com/articles/2019/09/05/1567670501099.html)



> docker方式安装kafka
```
sudo docker pull wurstmeister/kafka:0.10.2.0
```

> docker方式安装kafka-manager
```
sudo docker pull kafka-manager:alpine
```

> 查看所有镜像
```
sudo docker images
```
![kafka1.png](https://img.hacpai.com/file/2019/09/kafka1-7650bcee.png)


## 配置集群

> 节点

```sh
# 配置节点1
sudo docker run -itd \
--name=kafka1 \
-p 9092:9092 \
-v /var/logs1:/opt/kafka/logs \
-e KAFKA_ADVERTISED_HOST_NAME=127.0.0.1 \
-e JMX_PORT=9997 \
-e HOST_IP=127.0.0.1 \
-e KAFKA_ADVERTISED_PORT=9092 \
-e KAFKA_ZOOKEEPER_CONNECT=10.144.28.173:2181 \
-e KAFKA_BROKER_ID=1 \
-e KAFKA_HEAP_OPTS="-Xmx256M -Xms256M" \
wurstmeister/kafka:0.10.2.0


# 配置节点2
sudo docker run -itd \
--name=kafka2 \
-p 9093:9093 \
-v /var/logs2:/opt/kafka/logs \
-e KAFKA_ADVERTISED_HOST_NAME=127.0.0.1 \
-e JMX_PORT=9998 \
-e HOST_IP=127.0.0.1 \
-e KAFKA_ADVERTISED_PORT=9093 \
-e KAFKA_ZOOKEEPER_CONNECT=10.144.28.173:2181 \
-e KAFKA_BROKER_ID=2 \
-e KAFKA_HEAP_OPTS="-Xmx256M -Xms256M" \
wurstmeister/kafka:0.10.2.0


# 配置节点3
sudo docker run -itd \
--name=kafka \
-p 9094:9094 \
-v /var/logs3:/opt/kafka/logs \
-e KAFKA_ADVERTISED_HOST_NAME=127.0.0.1 \
-e JMX_PORT=9999 \
-e HOST_IP=127.0.0.1 \
-e KAFKA_ADVERTISED_PORT=9094 \
-e KAFKA_ZOOKEEPER_CONNECT=10.144.28.173:2181 \
-e KAFKA_BROKER_ID=2 \
-e KAFKA_HEAP_OPTS="-Xmx256M -Xms256M" \
wurstmeister/kafka:0.10.2.0

```

> 管理器

```
docker run -itd --restart=always --name=kafka-manager -p 9000:9000 -e ZK_HOSTS="10.144.28.173:2181" -e APPLICATION_SECRET=letmein sheepkiller/kafka-manager

```




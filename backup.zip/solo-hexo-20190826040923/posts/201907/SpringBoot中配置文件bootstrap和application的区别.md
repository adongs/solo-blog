title: Spring Boot 中配置文件bootstrap 和 application的区别
date: '2019-07-22 17:53:46'
updated: '2019-07-23 18:35:35'
tags: [springboot]
permalink: /articles/2019/07/22/1563789226071.html
---
![](https://img.hacpai.com/bing/20180611.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

##  Spring boot   配置文件如下

 1.  bootstrap(.yml 或者 properties)
 2.  application(.yml 或者 properties)


## 特性
1. bootstrap 由父ApplicationContext加载，比application优先加载
2. bootstrap里面的属性不能被覆盖

## 应用场景

> application

1. 自动化配置


> bootstrap

1. bootstrap 配置文件中添加连接到配置中心的配置属性来加载外部配置中心的配置信息
2. 一些固定的不能被覆盖的配置
3. 一些加密/解密的场景
4. 系统级别的一些参数配置



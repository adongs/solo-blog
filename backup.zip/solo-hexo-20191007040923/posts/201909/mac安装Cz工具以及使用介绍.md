title: mac安装Cz工具以及使用介绍
date: '2019-09-04 16:56:25'
updated: '2019-09-04 16:56:25'
tags: [Cz, Git]
permalink: /articles/2019/09/04/1567587385010.html
---
![](https://img.hacpai.com/bing/20190105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 简介
> 多人协作的项目中，如果Git的提交说明精准，在后期协作以及Bug处理时会变得有据可查，项目的开发可以根据规范的提交说明快速生成开发日志，从而方便开发者或用户追踪项目的开发信息和功能特性。

## 结构说明

> 总体

- `Git`**提交说明**可分为三个部分：`Header`、`Body`和`Footer`。结构如下
```
<Header>  <Body>  <Footer>
```

> Header
- `Header`部分包括三个字段`type`（必需）、`scope`（可选）和`subject`（必需）。结构如下
```
<type>(<scope>): <subject>
```
> type 

| 值 | 描述 |
| --- | --- |
| eat |  新增一个功能 |
| fix |  修复一个Bug |
| docs |  文档变更 |
| style |  代码格式（不影响功能，例如空格、分号等格式修正） |
| refactor |  代码重构 |
| perf |  改善性能 |
| test |  测试 |
| build |  变更项目构建或外部依赖（例如scopes: webpack、gulp、npm等） |
| ci |  更改持续集成软件的配置文件和package中的scripts命令，例如scopes: Travis, Circle等 |
| chore |  变更构建流程或辅助工具 |
| revert |  代码回退 |

> scope
```
`scope`说明`commit`影响的范围。`scope`依据项目而定，例如在业务项目中可以依据菜单或者功能模块划分，如果是组件库开发，则可以依据组件划分。该值可以省略
```
> subject
```
项目简短描述
```
> Body
```
`commit`的详细描述，说明代码提交的详细说明。
```
> Footer
```
1.如果代码的提交是**不兼容变更**或**关闭缺陷**，则`Footer`必需，否则可以省略.
2.当前代码与上一个版本不兼容，则`Footer`以**BREAKING CHANGE**开头，后面是对变动的描述、以及变动的理由和迁移方法
3.如果当前提交是针对特定的issue，那么可以在`Footer`部分填写需要关闭的单个 issue 或一系列issues
```






## 安装

> 使用npm进行安装

```sh
npm install -g commitizen cz-conventional-changelog
npm i -g cz-customizable
```

> 写入配置
```sh
echo'{ "path": "cz-customizable" }'  > ~/.czrc
```

> 在$HOME下创建.cz-config.js文件,内容如下

```
module.exports = {
  types: [
    {value: '特性',     name: '特性:    一个新的特性'},
    {value: '修复',      name: '修复:    修复一个Bug'},
    {value: '文档',     name: '文档:    变更的只有文档'},
    {value: '格式',    name: '格式:    空格, 分号等格式修复'},
    {value: '重构', name: '重构:    代码重构，注意和特性、修复区分开'},
    {value: '性能',     name: '性能:    提升性能'},
    {value: '测试',     name: '测试:    添加一个测试'},
    {value: '工具',    name: '工具:    开发工具变动(构建、脚手架工具等)'},
    {value: '回滚',   name: '回滚:    代码回退'}
    ],

  scopes: [{ name: '短信模块' }, { name: 'app模块' }, { name: '运营后台' }],

  allowTicketNumber: false,
  isTicketNumberRequired: false,
  ticketNumberPrefix: 'TICKET-',
  ticketNumberRegExp: '\\d{1,5}',

  // it needs to match the value for field type. Eg.: 'fix'
  /*
  scopeOverrides: {
    fix: [
      {name: 'merge'},
      {name: 'style'},
      {name: 'e2eTest'},
      {name: 'unitTest'}
    ]
  },
  */
  // override the messages, defaults are as follows
  messages: {
    type: '选择一种你的提交类型:',
    scope: '选择一个scope (可选):',
    // used if allowCustomScopes is true
    customScope: '自定义scope:',
    subject: '短说明:\n',
    body: '长说明，使用"|"换行(可选):\n',
    breaking: '非兼容性说明 (可选):\n',
    footer: '关联关闭的issue，例如:#31, #34(可选):\n',
    confirmCommit: '确定提交说明?'
  },
  allowCustomScopes: true,
  allowBreakingChanges: ['特性', '修复'],
  // skip any questions you want
  skipQuestions: ['body', 'footer'],

  // limit subject length
  subjectLimit: 100,
  // breaklineChar: '|', // It is supported for fields body and footer.
  // footerPrefix : 'ISSUES CLOSED:', // default value
};
```

## 使用方式

> 进入git管理的目录
![gitcz1.png](https://img.hacpai.com/file/2019/09/gitcz1-1c5b0999.png)

> 修改部分文件,执行add
```
git add ./
```
> 使用git cz 替换git commit 
![gitcz2.png](https://img.hacpai.com/file/2019/09/gitcz2-3fb69c35.png)

> 根据提示选择选项
![gitcz4.png](https://img.hacpai.com/file/2019/09/gitcz4-1d4eaec7.png)



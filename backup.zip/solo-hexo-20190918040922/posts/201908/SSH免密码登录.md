title: SSH免密码登录
date: '2019-08-12 17:21:22'
updated: '2019-08-12 17:21:22'
tags: [ssh]
permalink: /articles/2019/08/12/1565601682328.html
---
![](https://img.hacpai.com/bing/20190207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 创建秘钥
```sh
# 创建秘钥
ssh-keygen -t rsa
# 秘钥创建后会保存在 /home/.ssh目录下
cd ~/.ssh
# 查看
ls -lh
# id_rsa(私钥)     id_rsa.pub(公钥)
```
## 上传秘钥
```
scp -r -P 22(ssh端口号) id_rsa.pub(上传的文件) root(登录的用户名)@xxx.xxx.com(服务器地址IP也可以):/root/.ssh/(指定文件上传的到B电脑的那个目录下,一定要提前建立好目录)
```

## 配置服务器
```
# 登录服务器
ssh 登录用户名@服务器地址
# 如果存在 authorized_keys 文件
cat id_rsa.pub >> authorized_keys
# 如果不存在
mv id_rsa.pub authorized_keys
# 编辑配置(如果这个文件不存在就创建一个)
vim /etc/ssh_config
#在文件末尾加入
PubkeyAuthentication yes
```
## 配置快捷登录(现在已经免密钥登录了)
```
# 编辑文件内容如下(可以配置多个)
vim ~/.ssh/config

# Host 登录别名
# Port 登录端口
# HostName 登录地址
# User 登录用户名
# PreferredAuthentications 验证类型
# IdentityFile 私钥文件的路径
#
Host server  
Port 22  
HostName 192.168.0.1 
User root  
PreferredAuthentications publickey
IdentityFile ~/.ssh/id_rsa 
```

## 使用方式
```
# 即可直接登录
ssh server
# 可直接上传文件
scp 文件地址 root@server:/opt(上传的目录)
# 可直接下载文件到本地
scp root@server:/opt/test.txt ~/opt(本地目录)
```
